let allowAddOp = false;
let forceOp = false;
let mathfloor_q = false;
let hasKomma = false;
let lastOp, liczbasilnia, s, liczbaPodPierw, lastIsKomma;
var liczbaZPrz = document.getElementById("z");
var liczbaBezPrz = document.getElementById("bez");
var visible = document.getElementById("visible_output");
var calc = document.getElementById("calc_output");
liczbaZPrz.checked = true;
//make buttons on keyboard add stuff
function addnumb(value) {
  if(!forceOp){
  visible.value += value;
  allowAddOp = true;
  lastIsKomma = false;
  lastOp = "number";
  }
}

function action(operation) {
  if (allowAddOp === true || forceOp === true) {
    if (operation === ".") {
      if (!hasKomma && lastOp !== "siln" && lastOp !== "pierw") {
        visible.value += operation;
        allowAddOp = false;
        forceOp = false;
        hasKomma = true;
        lastIsKomma = true;
        lastOp = ".";
      }
    } else {
      visible.value += operation;
      allowAddOp = false;
      forceOp = false;
      hasKomma = false;
      lastIsKomma = false;
      lastOp = operation;
    }
  }
}
function keyPress(key) {
  const numbers = /[0-9]/;
  const ops = /^[+\-*/!^]+$/;
  if (numbers.test(key.key)) {
    if(key.key === "0"){
      if(visible.value !== ""){
        addnumb("0");
      }
    } else {
    addnumb(key.key);
    }
  }
  if (ops.test(key.key)) {
    if(key.key !== "!"){
      action(key.key);
    } else {
      silnia();
    }
  }
  if(key.keyCode === 13){
    showresult();
  }
  if(key.keyCode === 8){
    backspace();
  }
  if(key.key === "." || key.key === ","){
    action(".");
  }
}
function backspace() {
  visible.value = visible.value.slice(0, -1);
  calc.value = calc.value.slice(0, -1);
}

function clearAll() {
  visible.value = "";
  calc.value = "";
  allowAddOp = false;
  forceOp = false;
  hasKomma = false;
  lastIsKomma = false;
}

function showresult() {
  if (allowAddOp === true || forceOp === true) {
    calc.value = visible.value;
    if(calc.value.includes("^")){
      calc.value = calc.value.replace("^","**");
    }
    if(calc.value.includes("!")){
      const regex = /\![0-9]+/
      if(regex.test(calc.value)){
        calc.value = calc.value.replace(regex, s);
      }
      if(/![+\-*/]?/.test(calc.value)){
       calc.value = calc.value.replace(/![+\-*/]?/g,"");
      }
      }
    }
    if(calc.value.includes("·")){
      calc.value = calc.value.replace("·","*");
    }
    if(calc.value.includes("√(")){
      calc.value = calc.value.replace("√(","Math.sqrt(");
    }
    if (mathfloor_q === true && calc.value !== "") {
      calc.value = Math.floor(eval(calc.value));
      visible.value = calc.value;
    }
     if(mathfloor_q === false && calc.value !== ""){
      calc.value = eval(calc.value);
      visible.value = calc.value;
    }
    if(/[0-9]+\.0{6,}[1-9]?/.test(visible.value)){
      visible.value = visible.value.slice(0,-7);
    }
    lastOp = "";
    forceOp = false; 
    allowAddOp = true 
  }
function pierw() {
  if (allowAddOp === false && !lastIsKomma && lastOp !== "pierw" && lastOp !== "siln") {
    liczbaPodPierw = window.prompt("Wpisz liczbe ktora ma być pod pierwiastkiem", "");
    if (liczbasilnia / liczbasilnia === 1 && /^[0-9+\-*/]+$/.test(liczbaPodPierw)) {
      visible.value += "√(" + liczbaPodPierw + ")";
      forceOp = true;
      lastOp = "pierw";
    } else {
      console.log("Pierwiastek error - Niepoprawna liczba...");
      visible.placeholder = "ehhhhh, nie";
    }
  }
}
function silnia() {
  if (allowAddOp === false && !lastIsKomma && lastOp !== "siln" && lastOp !== "pierw") {
    liczbasilnia = window.prompt("Wpisz liczbe żeby dodać do silni");
    if (liczbasilnia / liczbasilnia === 1 && liczbasilnia < 22 && !liczbasilnia.includes(".")) {
      visible.placeholder = "";
      let i = 1;
      s = 1;
      while (i <= liczbasilnia) s *= i++;
      visible.value += "!" + liczbasilnia;
      forceOp = true;
      lastOp = "siln";
    } else {
      console.log("Silnia error - To nie liczba lub za duża (wieksza niż 21)");
      visible.placeholder = "ehhhhh, nie";
    }
  }
}

function zprz() {
  mathfloor_q = false;
  liczbaBezPrz.checked = false;
  liczbaZPrz.checked = true;
}
function bezprz() {
  mathfloor_q = true;
  liczbaZPrz.checked = false;
  liczbaBezPrz.checked = true;
}
  setInterval(() => {
    if(visible.value === ""){
      document.getElementById("oczekiwanie").innerHTML = "oczekuje liczby, (pierwiastku lub silnia)"
    } else if (forceOp === true) {
      document.getElementById("oczekiwanie").innerHTML = "oczekuje +, -, /, * lub ^";
    } else if (allowAddOp === true) {
      document.getElementById("oczekiwanie").innerHTML = "oczekuje liczby lub +, -, /, * lub ^";
    } else {
      document.getElementById("oczekiwanie").innerHTML = "oczekuje liczby, (pierwiastku lub silnia)";
    }
  }, 500);

  setInterval(() => {
    while (s === undefined) s = "/";
    console.log(
      "numb has komma?: "+hasKomma,
      "\r\nlast is komma?: "+ lastIsKomma,
      "\r\nliczbasilnia: "+liczbasilnia,
      "\r\ns = " + s,
      "| s.length = " + s.toString().length,
      "\r\nallowAddOp: "+allowAddOp,
      "\r\nround off: "+mathfloor_q,
      "\r\nlastOp: "+lastOp,
      "\r\nliczba pod pierw: "+liczbaPodPierw,
      "\r\n'"+visible.value+"'",
     "'"+ calc.value+"'",
    );
  }, 1300);

window.addEventListener('keydown', keyPress);